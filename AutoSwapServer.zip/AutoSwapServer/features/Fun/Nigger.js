import Settings from "../../config";

register("command", () => {

    const ol = Settings.l1
    const tl = Settings.l2

    ChatLib.command(`warp ${ol}`);
    setTimeout(() => {
        ChatLib.command(`warp ${tl}`);
    }, 4000); 
}).setName(`autoswapserver`);

register("command", () => {
    Settings.openGUI();
}).setName("ass")