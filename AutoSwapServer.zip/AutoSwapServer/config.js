import { @Vigilant, @ButtonProperty, @TextProperty, @SwitchProperty, @DecimalSliderProperty @SliderProperty, @SelectorProperty, @ColorProperty, Color } from "Vigilance";

@Vigilant("AutoSwapServer", `AutoSwapServer - Powered by Try2FindWhoasked`, {
})
class Settings {
    

    @TextProperty({
        name: "Warp Location 1",
        description: "Put the place you want to go before swap.",
        category: "Nigger",
        subcategory: "Nigger",
        triggerActionOnInitialization: false,
    })
    l1 = "";

    @TextProperty({
        name: "Target Warp Location",
        description: "Put the place you want to go.",
        category: "Nigger",
        subcategory: "Nigger",
        triggerActionOnInitialization: false,
    })
    l2 = "";

    
    
    constructor() {
        this.initialize(this);
    }
}


export default new Settings();
